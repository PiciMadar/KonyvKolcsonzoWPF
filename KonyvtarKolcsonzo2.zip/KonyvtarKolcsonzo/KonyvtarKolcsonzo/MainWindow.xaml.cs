﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using KonyvtarKolcsonzo.Model;
using SQLite;

namespace KonyvtarKolcsonzo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Konyvek> konyvekL;
        public MainWindow()
        {
            InitializeComponent();
            konyvekL = new List<Konyvek>();
            ReadDatabase();
        }

        private void ReadDatabase()
        {
            using (SQLite.SQLiteConnection sQLiteConnection = new SQLite.SQLiteConnection(App.databasePath))
            {
                sQLiteConnection.CreateTable<Konyvek>();
                konyvekL = sQLiteConnection.Table<Konyvek>().ToList();
            }
            if (konyvekL != null)
            {

            }
        }

        private void KilepesGomb01_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void KolcsonzesGomb_Click(object sender, RoutedEventArgs e)
        {
            KolcsonzoAblak newKolcsonzoWindow = new KolcsonzoAblak();
            newKolcsonzoWindow.ShowDialog();
        }
    }
}