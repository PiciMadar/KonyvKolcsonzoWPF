﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite;

namespace KonyvtarKolcsonzo.Model
{
    class Konyvek
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public string Cim { get; set; }
        public string Szerzo { get; set; }
        public string KiadasDatuma { get; set; }
        public string Nyelv {  get; set; }
        public string Mufaj {  get; set; }
    }
}
